package zookeeper;

import java.sql.Timestamp;

public class Message {
  public String Tipo;
  public String Key;
  public String Value;
  public Long ts;
  public String Ip_Destino;
  public int Porta_Destino;
  public String Ip_Requisitante;
  public int Porta_Requisitante;
}